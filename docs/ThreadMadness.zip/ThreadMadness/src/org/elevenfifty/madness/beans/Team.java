package org.elevenfifty.madness.beans;

public class Team {

	private String school;
	private String mascot;
	private int powerRanking = 0;
	private int seed;

	public Team(String school, String mascot, int powerRanking) {
		super();

		if (school == null) {
			throw new IllegalArgumentException("Every team needs a valid school!");
		}

		this.school = school;
		this.mascot = mascot;
		this.powerRanking = powerRanking;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Team)) {
			return false;
		}

		return ((Team) obj).school.equalsIgnoreCase(school);
	}

	@Override
	public int hashCode() {
		return school.hashCode();
	}

	public String getSchool() {
		return school;
	}

	public String getMascot() {
		return mascot;
	}

	public int getPowerRanking() {
		return powerRanking;
	}

	public String toString() {
		return "#" + seed + " " + this.school + " " + mascot + " (" + powerRanking + ")";
	}

	public int getSeed() {
		return seed;
	}

	public void setSeed(int seed) {
		this.seed = seed;
	}
}
