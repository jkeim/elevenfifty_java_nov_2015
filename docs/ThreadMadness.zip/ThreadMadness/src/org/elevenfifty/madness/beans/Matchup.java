package org.elevenfifty.madness.beans;

public class Matchup {

	private Team team1;
	private Team team2;
	private boolean team1Win = true;
	private boolean played = false;

	public Matchup(Team team1, Team team2) {
		super();
		this.team1 = team1;
		this.team2 = team2;
	}

	public Team getTeam1() {
		return team1;
	}

	public Team getTeam2() {
		return team2;
	}

	public void declareWinner(Team team) {
		played = true;
		team1Win = team1.equals(team);
	}

	public Team getWinner() {
		return (played) ? ((team1Win) ? team1 : team2) : null;
	}

	public Team getLoser() {
		return (played) ? ((team1Win) ? team2 : team1) : null;
	}

	public String toString() {
		return team1.toString() + " VS " + team2.toString();
	}
}
