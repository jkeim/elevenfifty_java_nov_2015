package org.elevenfifty.madness;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.elevenfifty.madness.beans.Matchup;
import org.elevenfifty.madness.beans.Team;

public class CallableTournament extends Tournament {
	private static final int GAMES_PLAYED = 1000;

	private ExecutorService executorService = Executors.newFixedThreadPool(10);

	public CallableTournament(List<Team> teams) {
		super(teams);
	}

	@Override
	public void handleMatchup(Matchup m) {
		List<Future<Boolean>> threads = new ArrayList<Future<Boolean>>();

		for (int i = 0; i < GAMES_PLAYED; i++) {
			MatchupRunnable thread = new MatchupRunnable(m);
			threads.add(executorService.submit(thread));
		}

		int diff = 0;
		// int count = 0;
		for (Future<Boolean> f : threads) {
			try {
				Boolean value = f.get(1, TimeUnit.MINUTES);

				diff += (value == null) ? 0 : ((value) ? 1 : -1);
				// count += (value == null) ? 0 : 1;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// System.out.println("Diff " + diff + " Count: " + count);

		m.declareWinner((diff >= 0) ? m.getTeam1() : m.getTeam2());
	}

	@Override
	protected double adjustPowerRanking(int power) {
		return power + (power * (Main.RAND.nextDouble() - 0.5));
	}

	private class MatchupRunnable implements Callable<Boolean> {
		Matchup m = null;

		private MatchupRunnable(Matchup m) {
			this.m = m;
		}

		@Override
		public Boolean call() throws Exception {
			double power1 = adjustPowerRanking(m.getTeam1().getPowerRanking());
			double power2 = adjustPowerRanking(m.getTeam2().getPowerRanking());

			return power1 >= power2;
		}
	}

}
