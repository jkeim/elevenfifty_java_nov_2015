package org.elevenfifty.madness;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.elevenfifty.madness.beans.Matchup;
import org.elevenfifty.madness.beans.Team;

public class Tournament {

	private List<Team> teams = new ArrayList<Team>();
	private int rounds = 0;

	public Tournament(List<Team> teams) {
		if (teams == null || teams.size() <= 1) {
			throw new IllegalArgumentException("A tournament must have teams");

		} else if (Math.log(teams.size()) / Math.log(2) % 2 != 0) {
			throw new IllegalArgumentException("A tournament should be a power of 2!  Actual[" + teams.size() + "]");
		}

		this.teams = teams;
		this.rounds = (int) (Math.log(teams.size()) / Math.log(2));

		seedTournament();
	}

	public final Team runSimulation() {
		int currentRound = 1;
		while (teams.size() > 1) {
			System.out.println("\nRound " + currentRound + " Results");
			List<Matchup> matchups = getMatchups(teams);

			// TODO Determine the matchup winner with Simulation Threads

			for (Matchup m : matchups) {
				handleMatchup(m);

				if (m.getLoser().getPowerRanking() > m.getWinner().getPowerRanking()) {
					System.out.println("UPSET " + m.getWinner() + " over " + m.getLoser());
				} else {
					System.out.println(m.getWinner() + " over " + m.getLoser());
				}

				teams.remove(m.getLoser());
			}
			currentRound++;

			System.out.println("Teams left " + teams.size());
		}

		// Return the Champion
		return teams.get(0);
	}

	public void handleMatchup(Matchup m) {
		double power1 = adjustPowerRanking(m.getTeam1().getPowerRanking());
		double power2 = adjustPowerRanking(m.getTeam2().getPowerRanking());

		m.declareWinner((power1 >= power2) ? m.getTeam1() : m.getTeam2());
	}

	protected double adjustPowerRanking(int power) {
		return power + (power * (Main.RAND.nextDouble() - 0.5));
	}

	protected final List<Matchup> getMatchups(List<Team> teamsLeft) {
		List<Matchup> games = new ArrayList<Matchup>();
		for (int i = 0; i < teamsLeft.size(); i += 2) {
			Matchup m = new Matchup(teamsLeft.get(i), teamsLeft.get(i + 1));
			games.add(m);
		}

		return games;
	}

	private void seedTournament() {
		Collections.sort(teams, (Team t1, Team t2) -> t2.getPowerRanking() - t1.getPowerRanking());

		System.out.println("\nTeams");
		for (int i = 0; i < teams.size(); i++) {
			teams.get(i).setSeed(i + 1);
			System.out.println(teams.get(i));
		}

		List<Integer> seedOrder = getSeedOrder();

		List<Team> seedOrdered = new ArrayList<Team>(teams.size());

		for (Integer index : seedOrder) {
			seedOrdered.add(teams.get(index - 1));
		}

		System.out.println("\nSeeded (" + seedOrdered.size() + ")");
		seedOrdered.forEach(t -> System.out.println(t));

		teams = seedOrdered;
	}

	private List<Integer> getSeedOrder() {
		// Start of seeds
		List<Integer> seeds = new ArrayList<Integer>();
		seeds.add(1);
		seeds.add(2);

		System.out.println(seeds);

		for (int i = 1; i < rounds; i++) {
			seeds = nextLayer(seeds);
		}

		System.out.println(seeds);
		return seeds;
	}

	// Used to get the seed order
	private List<Integer> nextLayer(List<Integer> seeds) {
		int length = seeds.size() * 2 + 1;
		List<Integer> expanded = new ArrayList<Integer>();

		for (int seed : seeds) {
			expanded.add(seed);
			expanded.add(length - seed);
		}

		return expanded;
	}
}
