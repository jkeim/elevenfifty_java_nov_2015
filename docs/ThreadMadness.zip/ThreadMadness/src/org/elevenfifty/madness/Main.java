package org.elevenfifty.madness;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.elevenfifty.madness.beans.Team;

public class Main {
	private static final String NAME_PLACEHOLDER = "<name>";
	private static final double ROUNDS = 6d;
	public static final int RANKING_BOUND = 50;
	public static Random RAND = new Random(System.currentTimeMillis());

	public static void main(String[] args) {
		// Load Team Naming Information
		List<String> locations = readStringList("locations.txt");
		List<String> mascots = readStringList("mascots.txt");
		List<String> names = readStringList("names.txt");

		List<Team> teams = new ArrayList<Team>();

		// Create Teams
		for (int i = 0; i < Math.pow(2d, ROUNDS); i++) {
			String location = getRandom(locations);
			String mascot = getRandom(mascots);
			String name = getRandom(names);

			int strength = RAND.nextInt(RANKING_BOUND) + RANKING_BOUND;
			teams.add(new Team(name.replaceAll(NAME_PLACEHOLDER, location), mascot, strength));
		}

		// Sort by power ranking

		// Output to see all the awesome names
		// teams.forEach(t -> System.out.println(t.toString()));

		// Tournament tourney = new Tournament(teams);
		Tournament tourney = new CallableTournament(teams);
		System.out.println("CHAMPION: " + tourney.runSimulation());
	}

	private static String getRandom(List<String> list) {
		return list.get(Math.abs(RAND.nextInt(list.size())));
	}

	private static List<String> readStringList(String filename) {
		List<String> lines = new ArrayList<String>();

		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(Main.class.getClassLoader().getResourceAsStream(filename)));

			String line = null;
			while ((line = reader.readLine()) != null) {
				lines.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
				}
			}
		}

		return lines;
	}

}
